export class Auth {


    logout(){
        //remove token in local storage


        //clear ng2 state


    }
}