"use strict";
var Auth = (function () {
    function Auth() {
    }
    Auth.prototype.logout = function () {
        //remove token in local storage
        //clear ng2 state
    };
    return Auth;
}());
exports.Auth = Auth;
//# sourceMappingURL=auth.js.map