"use strict";
// main entry point
var platform_browser_dynamic_1 = require('@angular/platform-browser-dynamic');
var app_module_1 = require('./app.module');
platform_browser_dynamic_1.platformBrowserDynamic().bootstrapModule(app_module_1.AppModule);
//Context, state keep
var Main = (function () {
    function Main() {
    }
    //init log
    Main.prototype.log = function () {
        //teamcity, 
    };
    //init db
    Main.prototype.initdb = function () {
    };
    return Main;
}());
exports.Main = Main;
//# sourceMappingURL=main.js.map